import Foundation
 
// Input Variables
let num1: Double = 10
let num2: Double = 5
 
// Operations
let addition = num1 + num2
let subtraction = num1 - num2
let multiplication = num1 * num2
let division = num1 / num2
let percentage = (num1 / num2) * 100
 
// Results
print("Addition: \(addition)")
print("Subtraction: \(subtraction)")
print("Multiplication: \(multiplication)")
print("Division: \(division)")
print("Percentage: \(percentage)%")
